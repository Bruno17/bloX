<?php

include_once(dirname(__FILE__)."/../../table/includes/getdatas.php");
?>
