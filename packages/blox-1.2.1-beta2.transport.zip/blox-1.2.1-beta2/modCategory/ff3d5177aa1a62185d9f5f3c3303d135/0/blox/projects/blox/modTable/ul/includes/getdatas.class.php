<?php

include_once(dirname(__FILE__)."/../../table/includes/getdatas.class.php");

return 'Blox_modTable_table';
?>
