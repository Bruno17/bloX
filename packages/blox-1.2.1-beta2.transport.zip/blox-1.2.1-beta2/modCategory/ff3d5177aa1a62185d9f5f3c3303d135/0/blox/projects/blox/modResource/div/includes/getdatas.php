<?php

include(dirname(__FILE__)."/../../table/includes/getdatas.php");

?>