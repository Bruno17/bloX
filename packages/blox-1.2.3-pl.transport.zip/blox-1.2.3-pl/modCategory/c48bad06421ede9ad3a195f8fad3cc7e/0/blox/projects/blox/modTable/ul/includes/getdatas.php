<?php

$class = 'Blox_modTable_Table';
$classfile = dirname(__FILE__)."/../../table/includes/getdatas.class.php";
?>