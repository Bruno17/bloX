Changelog
================================================================================

- 1.0
    - Initial public release as package for MODX Revolution

- 1.1

- 1.2

- 1.3

    - Compatibility with PHP 8
