<?php
/**
 * Default Lexicon Entries for bloX
 *
 * @package blox
 * @subpackage lexicon
 */
$_lang['blox'] = 'bloX';
