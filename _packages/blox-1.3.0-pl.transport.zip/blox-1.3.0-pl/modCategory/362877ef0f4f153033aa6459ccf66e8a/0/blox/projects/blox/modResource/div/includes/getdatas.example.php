<?php

$class = 'Blox_modResource_Table';
$classfile = dirname(__FILE__) . "/../../table/includes/getdatas.class.php";

